public class GameEntity {
    private String Heroes;


    public String getHeroes() {
        return Heroes;
    }

    public void setHeroes(String heroes) {
        Heroes = heroes;
    }
}
