public class Weapon  {
    private String Gun;

    public String getGun() {
        return Gun;
    }

    public void setGun(String gun) {
        Gun = gun;
    }
}
